/**
 * This package contains basic elements used inside of
 * USE diagrams.
 */
package org.tzi.use.gui.views.diagrams.elements;